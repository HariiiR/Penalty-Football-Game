import java.util.ArrayList;

public class PlayerPosition {
    private ArrayList<Integer> scores;
    public PlayerPosition(){
        ArrayList<Integer> newScores = new ArrayList<Integer>(4); 
        this.scores = newScores;

    }
    public void addScore(int score){ // adding scores to the scores arraylist
        
        scores.add(score);
    
        
    }
    public int getNumberScore(){ // iterates thru the arraylist and adds all the numbers and returns the total
        int totalScores =0;
            
             try {
                for(int k:scores)
                {
                  
                  totalScores =totalScores+ scores.get(k);
                }   
             } 
             
            catch (Exception e) {
                totalScores =totalScores+ 1;
            }
             
        return totalScores;
        
    }
    /// methods below overided in subclasses
    public String welcomeMessage(){
        return null;
    }
    public String getScore(){
        return null;
    }
   
    public String getPositionName(){ 
        return null;
    }

    public String getAimWord(){ 
        return null;
    }
    public String getLostMessage(){ 
        return null;
    }

   


}
