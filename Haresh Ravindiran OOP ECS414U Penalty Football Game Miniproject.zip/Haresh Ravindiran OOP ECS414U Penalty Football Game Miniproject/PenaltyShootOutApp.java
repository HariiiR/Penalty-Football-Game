/*
* Haresh Ravindiran 
* ECS414U - Object Oriented Programming 
* Queen Mary University of London, 2021/22.
* Penalty Shoot Out Game App Miniproject
*/
import java.awt.*;
import java.awt.event.*;
import java.io.*; 


public class PenaltyShootOutApp extends Frame{
    private static TextArea outputArea = new TextArea(); 
    private static TextArea inputArea = new TextArea(1,2); 
    private static TextArea inputAreaTwo = new TextArea(1,9); 
    private static Dialog errorBox;
    private static Dialog errorBoxTwo;
	private int round =1;
    // user and computer has an object reference to the superclass PlayerPosition 
    PlayerPosition playerOne; 
    PlayerPosition playerTwo; 
    
    
    
    public static void print(String text){ //print messages to the outputArea 
	   outputArea.setText(text);
	
    } 
    public static int addScoresRounds(int round, PlayerPosition player){ // adds the score for the player that is passed in and the round is passed in and incremented by 1
        player.addScore(1);
        round++;;
        return round;
    }
    public static int playWonRound(PlayerPosition player,int round){ // calls the addscoreround method for the user passed in as playerOne. Then prints the win statement and calls the getscore for the user and calls the (printGameStatement) and passes playerOne and round to it .
        round= addScoresRounds(round, player);
        print("The point is earned by the "+player.getPositionName()+"\n"+ (player).getScore()+ "\n" + printGameStatement(player,round));
        return round;
    }
    public static int playLostRound(PlayerPosition playerOne,PlayerPosition playerTwo, int round){ // calls the addscoreround method for the computer passed in as playerTwo. Then prints the lost statement and calls the getscore for the user and calls the (printGameStatement) and passes playerOne and round to it.
        round= addScoresRounds(round, playerTwo);
        print(playerOne.getLostMessage() + " "+ printGameStatement(playerOne,round));
        return round;
        
    }
    public static String printGameStatement(PlayerPosition player, int round){ // returns the next round statement dependant on whether the user is a goalkeeper or shooter
        return("Round " + round+" "+ player.getPositionName()+ " : Where would you like to "+ player.getAimWord()+" ?");
    }
    
    public static void setupGameButtons(Panel gameButtonsPanel,Frame window, Button shooterButton, Button goalkeeperButton,Button leftButton, Button centerButton, Button rightButton, PlayerPosition player,int round ){// Removes the shooter and goalkeeper buttons. Then adds the buttons for left,right,center buttons for the game. 
        gameButtonsPanel.remove(shooterButton);
        gameButtonsPanel.remove(goalkeeperButton);
        gameButtonsPanel.add(leftButton);
        gameButtonsPanel.add(centerButton);
        gameButtonsPanel.add(rightButton);
        window.setVisible(true);
        print("----You have selected to play as a "+ player.getPositionName() +"-------"+"\n"+ player.welcomeMessage()+"\n"  + printGameStatement(player,round)); // tells the user what they have selected to be. They can be shooter or goalkeeper.
    }
    public static void endGame(PlayerPosition playerOne,PlayerPosition playerTwo,Button leftButton, Button centerButton, Button rightButton,int i, Panel gameButtonsPanel,Button feedbackButton, Frame window, TextArea inputArea, Button clearButton, Button submitButton,Panel feedbackInputPanel, Button previousFeedbackButton, Button exit){ // When i equals 6, Shows gameover and scores for both user and computer. Then removes the game buttons and calls the feedback method.
        if (i==6){
            print("----------------------Game Over ---------------" +"\n" +
            (playerOne).getScore() +"\n" +(playerTwo).getScore());
            gameButtonsPanel.remove(leftButton);
            gameButtonsPanel.remove(centerButton);
            gameButtonsPanel.remove(rightButton);
            askFeedback(gameButtonsPanel, feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);
        }
    }
    
    public static void askFeedback(Panel gameButtonsPanel, Button feedbackButton,Frame window,TextArea inputArea, Button clearButton, Button submitButton, Panel feedbackInputPanel, Button previousFeedButton, Button exit){ //adds the input boxes, labels and buttons(clear,submit) needed for the feedback
        gameButtonsPanel.add(feedbackButton);
        window.setVisible(true);
        feedbackButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt){
            gameButtonsPanel.remove(feedbackButton);
            outputArea.setText("Rate the game out of 10 (Enter Integers Area)");
            Label nameLabel = new Label("Name");
            Label numberLabel = new Label("Number:");
            feedbackInputPanel.add(nameLabel);
            feedbackInputPanel.add(inputAreaTwo);
            feedbackInputPanel.add(numberLabel);
            feedbackInputPanel.add(inputArea);
            gameButtonsPanel.add (submitButton);
            gameButtonsPanel.add (clearButton);
            gameButtonsPanel.add(previousFeedButton);
            gameButtonsPanel.add(exit);
            window.setVisible(true);
        }
        });

        clearButton.addActionListener(new ActionListener(){ // once clicked,empties the input boxes 
            public void actionPerformed(ActionEvent evt){
            inputArea.setText("");
            inputAreaTwo.setText("");
        }
        });

        submitButton.addActionListener(new ActionListener(){   // once clicked, it gets the text from the input boxes and writes to the txt file. (Makes sure it is in integers and less than equal to 10 otherwise an error message will show)
            public void actionPerformed(ActionEvent evt){
            
            try {
                if (Integer.parseInt(inputArea.getText())<= 10 && Integer.parseInt(inputArea.getText())>= 0){
                FileWriter feedbackWriter = new FileWriter("Feedback.txt",true);
                BufferedWriter writeData = new BufferedWriter(feedbackWriter);
                writeData.write("Name: "+inputAreaTwo.getText()+ " Rating: " +Integer.parseInt(inputArea.getText())+"/10"+"\n");
                writeData.close();
                feedbackWriter.close();
                }
                else{
                   
                    errorBox.setVisible(true); // shows when user does NOT enter a number between 0-10
                }
                
            } catch (Exception e) {
                    
                
                    errorBoxTwo.setVisible(true); // shows when user does NOT enter numbers at all
            } 
            
            
            inputArea.setText("");
            inputAreaTwo.setText("");
        }
        });

        previousFeedButton.addActionListener(new ActionListener(){   // once clicked, this opens the txt so the user can see it
            public void actionPerformed(ActionEvent evt) {
                print("Previous Ratings File Opened");
                try {
                    Desktop.getDesktop().open(new java.io.File("Feedback.txt"));
                } catch (IOException e) {
                   print("error");
                }
            
        }
        });

        

    }
    public static int playGame( PlayerPosition playerOne,PlayerPosition playerTwo, Button button, int round,Button chooseButton){ // if the user chooses to be the shooter then the first statement is executed and if the user chooes to be the goalkeeper then the else if statement is executed. Inside both if statements there more if statements comparing the user's input with the random number(computer) and calls the winround method or lostround method if it satisfies one of the conditions 
        int number=RandomNumber.getRandomNumber(3);
        getComputerOutput(number);
        if (Integer.parseInt(chooseButton.getActionCommand())==1){ //user as shooter

            if (number!= Integer.parseInt(button.getActionCommand())){
                round=playWonRound(playerOne, round);
            
            }
            
            else{
                round = playLostRound(playerOne, playerTwo, round);
            }
    
        }
        else if (Integer.parseInt(chooseButton.getActionCommand())==2){// user as goalkeeper

            if (number== Integer.parseInt(button.getActionCommand())){
                round =playWonRound(playerOne, round);
            
            }
            else{
               
                round = playLostRound(playerOne, playerTwo, round);
            }
        
        }

        return round;
    }
    
    public static void getComputerOutput(int number){ // translates the number outputted by the randomizer so the user can see what the computer played in the terminal window
        if (number ==1){
            System.out.println("Computer plays left" );
        }
        else if (number ==2){
            System.out.println("Computer plays center" );
        }
        else if (number ==3){
            System.out.println("Computer plays right" );
        }


    }

    
    
    


    public PenaltyShootOutApp(){
        //creating panels for buttons and textAreas to be placed in.
        Panel gameButtonsPanel = new Panel();
        gameButtonsPanel.setLayout(new FlowLayout());

        Panel feedbackInputPanel = new Panel();
        feedbackInputPanel.setLayout(new FlowLayout());

        
        
        //creating buttons and frames for the game and error messages
        Frame window = new Frame("Penalty Shoot Out Game");  // Main Game window
        Frame windowTwo= new Frame(); // Window for Error message One 
        Frame windowThree = new Frame();  // Window for Error message Two 
        Button goalkeeperButton=new Button("Goalkeeper");
        Button shooterButton = new Button("Shooter");
        Button leftButton= new Button("Left");
        Button centerButton = new Button("Center");
        Button rightButton = new Button("Right");
        Button feedbackButton = new Button("Feedback");
        Button clearButton = new Button("Clear");
        Button submitButton = new Button("Submit");
        Button previousFeedbackButton = new Button("Read Previous Feedback");
        Button okButton = new Button ("Okay");
        Button okButtonTwo = new Button("Okay"); 
        Button exit = new Button("Exit");

       
        
        // creating dialogs 
        errorBox = new Dialog(windowTwo , "Number Range Error"); 
        errorBox.setLayout( new FlowLayout() );
        
        errorBoxTwo = new Dialog(windowThree , "Input Error"); 
        errorBoxTwo.setLayout( new FlowLayout() );  
        
              
        
        outputArea.setVisible(true);
		outputArea.setEditable(false);

	    window.add("North",outputArea);

        okButton.addActionListener ( new ActionListener() { // hides the errormessage one window when user presses ok button   
            public void actionPerformed( ActionEvent e )  
            {  
                errorBox.setVisible(false);  
                 
            }  
        });  

        errorBox.addWindowListener(new WindowAdapter() { // closes the errormessage one window when X is pressed
            public void windowClosing(WindowEvent e) {
                errorBox.dispose();
            }
        });
        
        okButtonTwo.addActionListener ( new ActionListener(){  // hides the errormessage two window when user presses okTwo button
            public void actionPerformed( ActionEvent e )  
            {  
                errorBoxTwo.setVisible(false);  
                 
            }  
        }); 

        errorBoxTwo.addWindowListener(new WindowAdapter() { // closes the errormessage two window when X is pressed
            public void windowClosing(WindowEvent e) {
                errorBoxTwo.dispose();
            }
        });

        exit.addActionListener ( new ActionListener() {  // closes the program when button pressed
            public void actionPerformed( ActionEvent e )  
            {  
                System.exit(0);
                 
            }  
        }); 
        
        //Dynamic Binding shown below the methods for playerOne and playerTwo are decided during runtime 
        shooterButton.addActionListener(new ActionListener(){ // once clicked, the user is Shooter now and a value of 1 is set for the (Shooter) button. Then sets up the game. Dependant on the user input (left/center/right) during the game, it calls the certain game methods and passes the pressed (left/center/right) button's value to playgame method
            
            public void actionPerformed(ActionEvent evt){
                    shooterButton.setActionCommand("1"); 
                     playerOne = new Shooter(); //user is Shooter
                     playerTwo = new Goalkeeper(); // Computer is Goalkeeper
                    setupGameButtons(gameButtonsPanel, window, shooterButton, goalkeeperButton, leftButton, centerButton, rightButton, playerOne,round);
                    leftButton.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent evt){
                            leftButton.setActionCommand("1");       
                            round =playGame(playerOne, playerTwo, leftButton, round, shooterButton); // left button and shooterbutton passed in (showing the unique parts passed in)
                            endGame(playerOne, playerTwo, leftButton, centerButton, rightButton, round, gameButtonsPanel,feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);
                                
                        }
                        });

                    centerButton.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent evt){
                                
                            centerButton.setActionCommand("2"); 
                            round= playGame(playerOne, playerTwo, centerButton, round, shooterButton); // center button and shooterbutton passed in (showing the unique parts passed in)
                            endGame(playerOne, playerTwo, leftButton, centerButton, rightButton, round, gameButtonsPanel,feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);
                                        
                                    
                        }
                        });


                    rightButton.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent evt){
                            rightButton.setActionCommand("3");  
                            round = playGame(playerOne, playerTwo, rightButton, round, shooterButton); // right button and shooterbutton passed in (showing the unique parts passed in)
                            endGame(playerOne, playerTwo, leftButton, centerButton, rightButton, round, gameButtonsPanel,feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);        
                        }
                        }); 
            
            }
            });

            goalkeeperButton.addActionListener(new ActionListener(){ // once clicked, the user is goalkeeper now and a value of 2 is set for the (goalkeeper) button. Then sets up the game. Dependant on the user input (left/center/right) during the game, it calls the certain game methods and passes the pressed (left/center/right) button's value to playgame method.
            
                public void actionPerformed(ActionEvent evt){
                        goalkeeperButton.setActionCommand("2"); 
                         playerOne = new Goalkeeper();  // user is Goalkeeper
                         playerTwo = new Shooter();  // Computer is Shooter
                        setupGameButtons(gameButtonsPanel, window, shooterButton, goalkeeperButton, leftButton, centerButton, rightButton, playerOne,round);
                        leftButton.addActionListener(new ActionListener(){
                            public void actionPerformed(ActionEvent evt){
                                leftButton.setActionCommand("1");       
                                round =playGame(playerOne, playerTwo, leftButton, round, goalkeeperButton); // left button and goalkeeperButton passed in (showing the unique parts passed in)
                                endGame(playerOne, playerTwo, leftButton, centerButton, rightButton, round, gameButtonsPanel,feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);
                                    
                            }
                            });
    
                        centerButton.addActionListener(new ActionListener(){
                            public void actionPerformed(ActionEvent evt){
                                    
                                centerButton.setActionCommand("2"); 
                                round = playGame(playerOne, playerTwo, centerButton, round, goalkeeperButton); // center button and goalkeeperButton passed in (showing the unique parts passed in)
                                endGame(playerOne, playerTwo, leftButton, centerButton, rightButton, round, gameButtonsPanel,feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);
                                            
                                        
                            }
                            });
    
    
                        rightButton.addActionListener(new ActionListener(){
                            public void actionPerformed(ActionEvent evt){
                                rightButton.setActionCommand("3"); 
                                round = playGame(playerOne, playerTwo, rightButton, round, goalkeeperButton); // right button and goalkeeperButton passed in (showing the unique parts passed in)
                                endGame(playerOne, playerTwo, leftButton, centerButton, rightButton, round, gameButtonsPanel,feedbackButton,window,inputArea,clearButton,submitButton,feedbackInputPanel,previousFeedbackButton,exit);        
                            }
                            }); 
                
                }
                });

                

        
        // adds the panels,goalkeeper,shooter buttons and labels to their corresponding frames and sets the sizes for the frames.
	    gameButtonsPanel.add(goalkeeperButton); 
        gameButtonsPanel.add(shooterButton);
        window.add(gameButtonsPanel);
        gameButtonsPanel.add(feedbackInputPanel);
        window.setSize(1000,1000);
        window.setVisible(true);
        errorBox.add(okButton);   
        errorBox.setSize(300,100); 
        errorBox.add( new Label ("Enter Integers between 0-10"));
        errorBoxTwo.add(okButtonTwo);
        errorBoxTwo.setSize(300,100); 
        errorBoxTwo.add( new Label ("Enter Integers Only"));
        
        //prints the welcome message
        print("------Welcome to Haresh's Penalty Shoot Out Game-----" + "\n"+ "Do you want to be the shooter or Goalkeeper?");
        
         //the X button closes our app
	    WindowCloser wc = new WindowCloser();
        window.addWindowListener(wc); 
        
        
        

    }
     
    
    
        
    public static void main(String[] args){
        new PenaltyShootOutApp();    
     
        }
        
        

}
