public class Goalkeeper extends PlayerPosition { //inheritance
    public Goalkeeper(){
        super();
    }
    
    public String welcomeMessage(){ //welcome message overided from playerposition
        return ("Goalkeeper is ready");
    }
   
    public String getScore() {   //get score overided from playerposition
        return ("-----------------Shots Saved --------------") + "\r\n"+ " Goalkeeper Score: " + getNumberScore() + "\r\n" + "-----------------------End-------------------";
        
    }

    public String getAimWord(){ //get Aim word overided from playerposition
        return "Dive";
    }
    public String getPositionName(){  //get Position Name overided from playerposition
        return "Goalkeeper";
    }
    public String getLostMessage(){  //get Lost Message overided from playerposition
        return "Shot not saved";
    }
}
