public class Shooter extends PlayerPosition { //inheritance
    public Shooter(){
        super();
        
    }
   
    public String welcomeMessage(){ //welcome message overided from playerposition
        return("Shooter is ready");
    }
    
    public String getScore() //get score overided from playerposition
    {   
        return ("-----------------Shots Scored--------------") + "\r\n" + " Shooter Score: " + getNumberScore() + "\r\n" + "-----------------------End-------------------";
        
    }
    public String getAimWord(){ //get Aim word overided from playerposition
        return "Shoot";
    }
    public String getPositionName(){  //get Position Name overided from playerposition
        return "Shooter";
    }
    public String getLostMessage(){  //get Lost Message overided from playerposition
        return "Shot missed";
    }
}
