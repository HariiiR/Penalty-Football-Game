import java.util.Random;
public class RandomNumber {
    public static int getRandomNumber(int num) // static method which generates numbers up to the given number that is passed in
    {
        Random numberGenerator = new Random();
        int randomNumber = 1 + numberGenerator.nextInt(num); 
        return randomNumber;
    }
}
